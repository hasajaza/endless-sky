/* Person.cpp
Copyright (c) 2015 by Michael Zahniser

Endless Sky is free software: you can redistribute it and/or modify it under the
terms of the GNU General Public License as published by the Free Software
Foundation, either version 3 of the License, or (at your option) any later version.

Endless Sky is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with
this program. If not, see <https://www.gnu.org/licenses/>.
*/

#include "Person.h"

#include "DataNode.h"
#include "FormationPattern.h"
#include "GameData.h"
#include "Government.h"
#include "Ship.h"
#include "ShipEvent.h"
#include "System.h"

#include <algorithm>

using namespace std;



void Person::Load(const DataNode &node, const ConditionsStore *playerConditions,
	const set<const System *> *visitedSystems, const set<const Planet *> *visitedPlanets)
{
	name = node.Token(1);
	isLoaded = true;
	for(const DataNode &child : node)
	{
		const string &key = child.Token(0);
		bool hasValue = child.Size() >= 2;

		if(key == "system")
			location.Load(child, visitedSystems, visitedPlanets);
		else if(key == "frequency" && hasValue)
			frequency = child.Value(1);
		else if(key == "formation" && hasValue)
			formationPattern = GameData::Formations().Get(child.Token(1));
		else if(key == "ship" && hasValue)
			shipFactory.Load(child, playerConditions);
		else if(key == "government" && hasValue)
			government = GameData::Governments().Get(child.Token(1));
		else if(key == "personality")
			personality.Load(child);
		else if(key == "phrase")
			hail.Load(child);
		else if(key == "never dies")
			neverDies = true;
		else if(key == "must destroy all")
			mustDestroyAll = true;
		else
			child.PrintTrace("Skipping unrecognized attribute:");
	}
}



bool Person::IsValid() const
{
	if(!isLoaded || !government || !government->IsDefined())
		return false;
	if(!shipFactory.IsValid())
		return false;
	return true;
}



// Finish loading all the ships in this person specification.
void Person::FinishLoading()
{
	auto nameFunc = [this](const shared_ptr<Ship> &) -> string { return name; };
	shipFactory.FinishLoading();
	shipFactory.Instantiate(ships, nameFunc);
	if(formationPattern)
		for(const shared_ptr<Ship> &ship : ships)
			ship->SetFormationPattern(formationPattern);
}



// Prevent this person from being spawned in any system.
void Person::NeverSpawn()
{
	frequency = 0;
}



// Find out how often this person should appear in the given system. If this
// person is dead or already active, this will return zero.
int Person::Frequency(const System *system) const
{
	// Because persons always enter a system via one of the regular hyperspace
	// links, don't create them in systems with no links.
	if(!system || !frequency || system->Links().empty() || !IsValid() || IsDestroyed() || IsPlaced())
		return 0;

	return (location.IsEmpty() || location.Matches(system)) ? frequency : 0;
}



// Get the person's characteristics. The ship object is persistent, i.e. it
// will be recycled every time this person appears.
const list<shared_ptr<Ship>> &Person::Ships() const
{
	return ships;
}



const Government *Person::GetGovernment() const
{
	return government;
}



const Personality &Person::GetPersonality() const
{
	return personality;
}



const Phrase &Person::GetHail() const
{
	return hail;
}



bool Person::IsDestroyed() const
{
	if(ships.empty() || !ships.front())
		return true;
	if(neverDies)
		return false;
	if(mustDestroyAll)
		return ranges::all_of(ships, [](const shared_ptr<Ship> &ship) -> bool { return ship->IsDestroyed(); } );
	return ships.front()->IsDestroyed();
}



// Mark this person as destroyed.
void Person::Destroy()
{
	for(const shared_ptr<Ship> &ship : ships)
		ship->Destroy();
}



// Mark this person as no longer destroyed.
void Person::Restore()
{
	for(const shared_ptr<Ship> &ship : ships)
	{
		ship->Restore();
		ship->SetSystem(nullptr);
		ship->SetPlanet(nullptr);
	}
}



// Check if a person is already placed somewhere.
bool Person::IsPlaced() const
{
	for(const shared_ptr<Ship> &ship : ships)
		if(ship->GetSystem())
			return true;

	return false;
}



// Mark this person as being no longer "placed" somewhere.
void Person::ClearPlacement()
{
	if(!IsDestroyed())
		Restore();
}



bool Person::Do(const ShipEvent &event)
{
	// First, check if this ship is part of this Person. If not, do nothing. If it
	// is part of this Person and it just got captured, replace it with a copy of
	// itself so that when this Person is respawned, it doesn't steal the ship away
	// from the capturer.
	const shared_ptr<Ship> &target = event.Target();
	int type = event.Type();
	for(shared_ptr<Ship> &ptr : ships)
		if(ptr == target)
		{
			if(type & ShipEvent::CAPTURE)
			{
				shared_ptr<Ship> copy = make_shared<Ship>(*ptr);
				// Unlike NPC, we don't copy the UUID here, since the next time
				// this ship is spawned, it'll be a different instance.
				copy->Destroy();
				ptr.swap(copy);
			}
			return true;
		}
	return false;
}
